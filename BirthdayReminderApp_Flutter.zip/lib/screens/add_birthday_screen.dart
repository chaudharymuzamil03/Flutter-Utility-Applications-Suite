import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AddBirthdayScreen extends StatefulWidget {
  @override
  _AddBirthdayScreenState createState() => _AddBirthdayScreenState();
}

class _AddBirthdayScreenState extends State<AddBirthdayScreen> {
  final _nameController = TextEditingController();
  DateTime? _selectedDate;

  void _pickDate() async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  void _saveBirthday() {
    if (_nameController.text.isEmpty || _selectedDate == null) return;
    Navigator.pop(context, {
      'name': _nameController.text,
      'date': DateFormat('dd-MM-yyyy').format(_selectedDate!)
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Birthday')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text(
                  _selectedDate == null
                      ? 'No date chosen!'
                      : DateFormat('dd-MM-yyyy').format(_selectedDate!),
                ),
                Spacer(),
                TextButton(
                  onPressed: _pickDate,
                  child: Text('Choose Date'),
                )
              ],
            ),
            Spacer(),
            ElevatedButton(
              onPressed: _saveBirthday,
              child: Text('Save'),
            )
          ],
        ),
      ),
    );
  }
}