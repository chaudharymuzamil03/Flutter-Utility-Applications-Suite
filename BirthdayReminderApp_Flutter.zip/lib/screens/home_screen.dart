import 'package:flutter/material.dart';
import 'package:birthday_reminder_flutter/screens/add_birthday_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, String>> birthdayList = [];

  void addBirthday(String name, String date) {
    setState(() {
      birthdayList.add({'name': name, 'date': date});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Birthday Reminder')),
      body: ListView.builder(
        itemCount: birthdayList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(birthdayList[index]['name']!),
            subtitle: Text(birthdayList[index]['date']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddBirthdayScreen(),
            ),
          );
          if (result != null) {
            addBirthday(result['name'], result['date']);
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}